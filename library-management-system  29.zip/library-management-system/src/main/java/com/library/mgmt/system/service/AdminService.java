package com.library.mgmt.system.service;

import java.util.List;

import com.library.mgmt.system.dto.AdminDTO;
import com.library.mgmt.system.entity.Admin;

public interface AdminService 
{
	AdminDTO createAdmin(Admin admin);
	List<AdminDTO> getAllAdmins();
	AdminDTO getAdminById(int id);
	AdminDTO updateAdmin(int id,Admin admin);
	String deleteAdmin(int id);
	
	

}
