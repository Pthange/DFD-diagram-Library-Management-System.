package com.library.mgmt.system.service;

import java.util.List;

import com.library.mgmt.system.dto.AuthorDTO;
import com.library.mgmt.system.entity.Author;

public interface AuthorService 
{
	    AuthorDTO createAuthor(Author author);
	    List<AuthorDTO> getAllAuthors();
	    AuthorDTO getAuthorById(int id);
	    AuthorDTO getAuthorByName(String name);
	    AuthorDTO updateAuthor(int id, Author author);
	    String deleteAuthor(int id);

}
