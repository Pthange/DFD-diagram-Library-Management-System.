package com.library.mgmt.system.service;

import java.util.List;

import com.library.mgmt.system.dto.TransactionDTO;
import com.library.mgmt.system.entity.Transaction;

public interface TransactionService {

	TransactionDTO createTransaction(Transaction transaction);
	List<TransactionDTO> getAllTransactions();
	TransactionDTO getTransactionById(int id);
	TransactionDTO updateTransaction(int id,Transaction transaction);
	String deleteTransaction(int id);
	
}
