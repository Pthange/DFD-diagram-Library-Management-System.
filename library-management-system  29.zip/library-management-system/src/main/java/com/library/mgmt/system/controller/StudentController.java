package com.library.mgmt.system.controller;

import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.library.mgmt.system.dto.StudentDTO;
import com.library.mgmt.system.entity.Student;
import com.library.mgmt.system.exception.StudentNotFoundException;
import com.library.mgmt.system.service.StudentService;
import com.library.mgmt.system.util.Converter;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@RestController
//@RequestMapping("/student")
public class StudentController {

	@Autowired
	private StudentService studentService;
	
	@Autowired
	private Converter converter;
	
//@PostMapping("/api/createStudent")	
// Student createStudent(@RequestBody Student student)	
// {
//	return studentService.createStudent(student); 
// }
	
	@PostMapping("/createStudent")	
	 ResponseEntity<StudentDTO> createStudent(@Valid @RequestBody StudentDTO studentDTO)throws StudentNotFoundException
	 {
		final Student student=converter.convertToStudentEntity(studentDTO);
		return new ResponseEntity<StudentDTO>(studentService.createStudent(student),HttpStatus.CREATED); 
	 }
	
	@GetMapping("/getAllStudents")
	List<StudentDTO> getAllStudents()
	{
		return studentService.getAllStudents();
	}
	
	@GetMapping("/getStudentById/{sid}")
	StudentDTO getStudentById(@PathVariable("sid") int id)throws StudentNotFoundException
   {
	   return studentService.getStudentById(id);
   }
	
	@PutMapping("/updateStudent/{id}")
	StudentDTO	updateStudent(@Valid @PathVariable int id,@RequestBody StudentDTO studentDTO)throws StudentNotFoundException
{
		final Student student=converter.convertToStudentEntity(studentDTO);
	return studentService.updateStudent(id, student);
}
	@DeleteMapping("/deleteStudent/{id}")
	String deleteStudent(@PathVariable int id)
	{
		return studentService.deleteStudent(id);
	}
	
//	@PostMapping("/login")  //login for students
//	public String validate(@RequestBody Student student) throws ServletException {
//		String jwtToken = "";
//
//		if (student.getStudusername() == null || student.getStudpassword() == null) {
//			throw new ServletException("Please Fill in Student Name and Password");
//		}
//
//		String userName = student.getStudusername();
//		String password = student.getStudpassword();
//		// Check in the database whether the login and password are present or not
//		student = studentService.login(userName, password);
//
//		if (student == null) {
//			throw new ServletException("Student not found");
//		}
//
//		jwtToken = Jwts.builder().setSubject(userName).claim("studentName", student.getStudusername()).
//				setIssuedAt(new Date()).signWith(SignatureAlgorithm.HS256, "secretkey").compact();
//
//		return jwtToken;
//	}
}
