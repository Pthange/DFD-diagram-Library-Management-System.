package com.library.mgmt.system.util;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import com.library.mgmt.system.dto.AdminDTO;
import com.library.mgmt.system.dto.AuthorDTO;
import com.library.mgmt.system.dto.BookDTO;
import com.library.mgmt.system.dto.FacultyDTO;
import com.library.mgmt.system.dto.LibrarianDTO;
import com.library.mgmt.system.dto.StudentDTO;
import com.library.mgmt.system.dto.TransactionDTO;
import com.library.mgmt.system.entity.Admin;
import com.library.mgmt.system.entity.Author;
import com.library.mgmt.system.entity.Book;
import com.library.mgmt.system.entity.Faculty;
import com.library.mgmt.system.entity.Librarian;
import com.library.mgmt.system.entity.Student;
import com.library.mgmt.system.entity.Transaction;

@Component
public class Converter 
{
	//convert from DTO to Entity

	public  Student convertToStudentEntity(StudentDTO studentDTO)
	{
		Student student=new Student();
		if(studentDTO!=null)
		{
			BeanUtils.copyProperties(studentDTO, student);
		}
	     return student;
	}

	//convert from Entity to DTO
	public StudentDTO convertToStudentDTO(Student student)
	{
		StudentDTO studentDTO=new StudentDTO();
		if(student!=null)
		{
			BeanUtils.copyProperties(student, studentDTO);
		}
		return studentDTO;
	}
	
	// Convert from AdminDTO to Admin entity
    public Admin convertToAdminEntity(AdminDTO adminDTO) {
        Admin admin = new Admin();
        if (adminDTO != null) 
        {
            BeanUtils.copyProperties(adminDTO, admin);
        }
        return admin;
    }

    // Convert from Admin entity to AdminDTO
    public AdminDTO convertToAdminDTO(Admin admin) {
        AdminDTO adminDTO = new AdminDTO();
        if (admin != null) {
            BeanUtils.copyProperties(admin, adminDTO);
        }
        return adminDTO;
    }
    
 // Convert from AuthorDTO to Author entity
    public Author convertToAuthorEntity(AuthorDTO authorDTO) {
        Author author = new Author();
        if (authorDTO != null) {
            BeanUtils.copyProperties(authorDTO, author);
            
        }
        return author;
    }

    // Convert from Author entity to AuthorDTO
    public AuthorDTO convertToAuthorDTO(Author author) {
        AuthorDTO authorDTO = new AuthorDTO();
        if (author != null) {
            BeanUtils.copyProperties(author, authorDTO);
            
        }
        return authorDTO;
    }

    
 // Convert from BookDTO to Book entity
    public Book convertToBookEntity(BookDTO bookDTO) {
        Book book = new Book();
        if (bookDTO != null) {
            BeanUtils.copyProperties(bookDTO, book);
            
        }
        return book;
    }

    // Convert from Book entity to BookDTO
    public BookDTO convertToBookDTO(Book book) {
        BookDTO bookDTO = new BookDTO();
        if (book != null) {
            BeanUtils.copyProperties(book, bookDTO);
         
        }
        return bookDTO;
    }

    
 // Convert from TransactionDTO to Transaction entity
    public Transaction convertToTransactionEntity(TransactionDTO transactionDTO) {
        Transaction transaction = new Transaction();
        if (transactionDTO != null) {
            BeanUtils.copyProperties(transactionDTO, transaction);
            
        }
        return transaction;
    }

    // Convert from Transaction entity to TransactionDTO
    public TransactionDTO convertToTransactionDTO(Transaction transaction) {
        TransactionDTO transactionDTO = new TransactionDTO();
        if (transaction != null) {
            BeanUtils.copyProperties(transaction, transactionDTO);
            
        }
        return transactionDTO;
    }
    
 // Convert from FacultyDTO to Faculty entity
    public Faculty convertToFacultyEntity(FacultyDTO facultyDTO) {
        Faculty faculty = new Faculty();
        if (facultyDTO != null) {
            BeanUtils.copyProperties(facultyDTO, faculty);
            
        }
        return faculty;
    }

    // Convert from Faculty entity to FacultyDTO
    public FacultyDTO convertToFacultyDTO(Faculty faculty) {
        FacultyDTO facultyDTO = new FacultyDTO();
        if (faculty != null) {
            BeanUtils.copyProperties(faculty, facultyDTO);
            // You may need to copy additional properties if necessary
        }
        return facultyDTO;
    }

 // Convert from LibrarianDTO to Librarian entity
    public Librarian convertToLibrarianEntity(LibrarianDTO librarianDTO) {
        Librarian librarian = new Librarian();
        if (librarianDTO != null) {
            BeanUtils.copyProperties(librarianDTO, librarian);
            
        }
        return librarian;
    }

    // Convert from Librarian entity to LibrarianDTO
    public LibrarianDTO convertToLibrarianDTO(Librarian librarian) {
        LibrarianDTO librarianDTO = new LibrarianDTO();
        if (librarian != null) {
            BeanUtils.copyProperties(librarian, librarianDTO);
            
        }
        return librarianDTO;
    }




}
