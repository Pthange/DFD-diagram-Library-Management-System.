package com.library.mgmt.system.dao;



import org.springframework.data.jpa.repository.JpaRepository;


import com.library.mgmt.system.entity.Transaction;

public interface TransactionRepository extends JpaRepository<Transaction,Integer>{
	//public Transaction findByid(int id);
}