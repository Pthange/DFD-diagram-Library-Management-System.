package com.library.mgmt.system.exception;
@SuppressWarnings("serial")
public class AuthorNotFoundException extends Exception{

	public AuthorNotFoundException(String message)
	{
		super(message);
	}

}
