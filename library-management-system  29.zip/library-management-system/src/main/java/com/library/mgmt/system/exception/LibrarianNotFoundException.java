package com.library.mgmt.system.exception;
@SuppressWarnings("serial")
public class LibrarianNotFoundException extends Exception{

	public LibrarianNotFoundException(String message)
	{
		super(message);
	}

}
