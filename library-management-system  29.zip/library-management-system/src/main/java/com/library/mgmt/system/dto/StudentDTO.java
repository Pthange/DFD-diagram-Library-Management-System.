package com.library.mgmt.system.dto;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.library.mgmt.system.entity.Admin;
import com.library.mgmt.system.entity.Author;
import com.library.mgmt.system.entity.Book;
import com.library.mgmt.system.entity.Librarian;

import lombok.Data;

@Data 
//Lombok's @Data annotation will automatically gives required methods like constructors,getter and setter
public class StudentDTO {

	@NotNull(message="Name cannot be null")
	private String studName;
	@NotNull
	@Email(message="Enter proper email")
	private String studEmail;
	@NotBlank(message="Enter proper username")
	private String studusername;
	@NotBlank(message="Enter proper password")
	private String studpassword;
	@NotBlank
	private String studDOB;
	@NotBlank(message="Enter Right Gender")
	private String studGender;
	@NotNull
	private String studAddress;
	@NotNull
	@Pattern(regexp ="^\\d{10}$", message="Mobile number should be of 10 digits")
	private String studMobno;


////	@OneToMany(cascade=CascadeType.ALL)
////	@JsonManagedReference
////	//use JsonManagedReference for bidirectional relationship
//	private List<Book> books;
////
//////	@OneToOne
////	@JoinColumn(name = "admin_id") 
//	private Admin admin;
////	
//////	@ManyToOne
//	private Librarian librarian;
	

}
