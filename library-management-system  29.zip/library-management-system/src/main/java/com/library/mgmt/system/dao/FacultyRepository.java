package com.library.mgmt.system.dao;


import org.springframework.data.jpa.repository.JpaRepository;


import com.library.mgmt.system.entity.Faculty;

public interface FacultyRepository extends JpaRepository<Faculty,Integer>{
	//public Faculty findByfacId(int id);
}
