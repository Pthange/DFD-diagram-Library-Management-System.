package com.library.mgmt.system.serviceimpl;


import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.library.mgmt.system.dao.AuthorRepository;
import com.library.mgmt.system.dto.AuthorDTO;
import com.library.mgmt.system.entity.Author;
import com.library.mgmt.system.exception.ResourceNotFoundException;
import com.library.mgmt.system.service.AuthorService;
import com.library.mgmt.system.util.Converter;

@Service
public class AuthorServiceImpl implements AuthorService {

    @Autowired
    private AuthorRepository authorRepository;

    @Autowired
    private Converter converter;

    @Override
    public AuthorDTO createAuthor(Author author) {
        // Set specific attributes for Author entity as needed
    	author.setAuthorName(author.getAuthorName());
    	author.setNationality(author.getNationality());
        Author authorEntity = authorRepository.save(author);
        return converter.convertToAuthorDTO(authorEntity);
    }

    @Override
    public List<AuthorDTO> getAllAuthors() {
        List<Author> authors = authorRepository.findAll();

        List<AuthorDTO> dtoList = new ArrayList<>();
        for (Author author : authors) {
            dtoList.add(converter.convertToAuthorDTO(author));
        }

        return dtoList;
    }

    @Override
    public AuthorDTO getAuthorById(int id) {
        Author author = authorRepository.findById(id).orElseThrow(() ->
                new ResourceNotFoundException("Author", "Id", id));
        return converter.convertToAuthorDTO(author);
    }

    @Override
    public AuthorDTO getAuthorByName(String name) {
        Author author = authorRepository.findByauthorName(name);
//        		.orElseThrow(() ->     
        //new ResourceNotFoundException("Author", "Name", name));
        return converter.convertToAuthorDTO(author);
    }
   


    @Override
    public AuthorDTO updateAuthor(int id, Author author) {
        Author authorEntity = authorRepository.findById(id).orElseThrow(() ->
                new ResourceNotFoundException("Author", "Id", id));
        author.setAuthorName(author.getAuthorName());
    	author.setNationality(author.getNationality());
        // Update specific attributes for Author entity as needed
        
        Author updatedAuthor = authorRepository.save(authorEntity);
        return converter.convertToAuthorDTO(updatedAuthor);
    }

    @Override
    public String deleteAuthor(int id) {
        authorRepository.findById(id).orElseThrow(() ->
                new ResourceNotFoundException("Author", "Id", id));

        authorRepository.deleteById(id);
        return "Author deleted successfully!";
    }

	
}
