package com.library.mgmt.system.service;

import java.util.List;

import com.library.mgmt.system.dto.StudentDTO;
import com.library.mgmt.system.entity.Student;

public interface StudentService {

	StudentDTO createStudent(Student student);
	List<StudentDTO> getAllStudents();
	StudentDTO getStudentById(int id);
	StudentDTO updateStudent(int id,Student student);
	String deleteStudent(int id);
	//Student login(String studusername,String studpassword);
	
	
}
