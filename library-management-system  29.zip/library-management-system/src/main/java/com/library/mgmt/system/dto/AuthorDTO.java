package com.library.mgmt.system.dto;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.library.mgmt.system.entity.Book;
import com.library.mgmt.system.entity.Faculty;
import com.library.mgmt.system.entity.Student;

import lombok.Data;

@Data
public class AuthorDTO //extends StudentDTO
{

	@NotNull(message="Author cannot be null")
	private String authorName;
	@NotBlank
    private String nationality;
	@NotBlank(message="Enter Right Gender")
    private String authorGender;

//	@OneToMany(mappedBy = "author", cascade = CascadeType.ALL)
//    private List<Book> books;
    

}
