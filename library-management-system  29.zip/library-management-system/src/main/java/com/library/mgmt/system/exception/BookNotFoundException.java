package com.library.mgmt.system.exception;
@SuppressWarnings("serial")
public class BookNotFoundException extends Exception{

	public BookNotFoundException(String message)
	{
		super(message);
	}

}
