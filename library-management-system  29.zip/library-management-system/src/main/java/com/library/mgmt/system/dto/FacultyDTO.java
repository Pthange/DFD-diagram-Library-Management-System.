package com.library.mgmt.system.dto;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.library.mgmt.system.entity.Admin;
import com.library.mgmt.system.entity.Author;
import com.library.mgmt.system.entity.Book;
import com.library.mgmt.system.entity.Librarian;

import lombok.Data;

@Data 
//Lombok's @Data annotation will automatically gives required methods like constructors,getter and setter
public class FacultyDTO //extends StudentDTO
{

	@NotNull(message=" Faculty cannot be null")
	private String facName;
	@NotNull
	@Email(message="Enter proper email")
	private String facEmail;
	@NotBlank(message="Enter proper username")
	private String facusername;
	@NotBlank(message="Enter proper password")
	private String facpassword;
	@NotBlank
	private String facDOB;
	@NotBlank(message="Enter Right Gender")
	private String facGender;
	@NotNull
	private String facAddress;
	@NotNull
	@Pattern(regexp ="^\\d{10}$", message="Mobile number should be of 10 digits")
	private String facMobno;

////	@OneToOne
//	private Admin admin;
//	
////	@OneToOne
//	private Librarian librarian;
//
////	@OneToMany(mappedBy = "faculty", cascade = CascadeType.ALL)
////	@JsonManagedReference
////	//use JsonManagedReference for bidirectional relationship
//	private List<Book> books;
	

}
