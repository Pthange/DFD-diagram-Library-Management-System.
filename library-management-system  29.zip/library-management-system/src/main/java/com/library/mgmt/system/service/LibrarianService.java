package com.library.mgmt.system.service;

import java.util.List;

import com.library.mgmt.system.dto.LibrarianDTO;
import com.library.mgmt.system.entity.Librarian;

public interface LibrarianService {

	 LibrarianDTO createLibrarian(Librarian librarian);
	    List<LibrarianDTO> getAllLibrarians();
	    LibrarianDTO getLibrarianById(int id);
	    LibrarianDTO updateLibrarian(int id, Librarian librarian);
	    String deleteLibrarian(int id);
}
