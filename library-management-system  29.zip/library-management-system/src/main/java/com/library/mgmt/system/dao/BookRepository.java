package com.library.mgmt.system.dao;



import org.springframework.data.jpa.repository.JpaRepository;

import com.library.mgmt.system.entity.Book;




public interface BookRepository extends JpaRepository<Book,Integer>{
	//public Book findBybookId(int id);
	public Book findBytitle(String title);

	
}
