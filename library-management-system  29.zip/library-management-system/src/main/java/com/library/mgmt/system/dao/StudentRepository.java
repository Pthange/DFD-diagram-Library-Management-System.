package com.library.mgmt.system.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.library.mgmt.system.entity.Student;


public interface StudentRepository extends JpaRepository<Student,Integer>{
	//public Student findByStudId(int id);
	//Student findBystudusernameAndstudpassword(String studusername,String studpassword);
}
