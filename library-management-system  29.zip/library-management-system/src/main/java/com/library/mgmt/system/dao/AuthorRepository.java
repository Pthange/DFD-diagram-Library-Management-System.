package com.library.mgmt.system.dao;



import org.springframework.data.jpa.repository.JpaRepository;

import com.library.mgmt.system.entity.Author;

public interface AuthorRepository extends JpaRepository<Author,Integer>{
	//public Author findByauthorId(int id);
	public Author findByauthorName(String name);

	

}
