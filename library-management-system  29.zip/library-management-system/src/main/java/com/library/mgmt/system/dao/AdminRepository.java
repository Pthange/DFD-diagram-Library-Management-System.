package com.library.mgmt.system.dao;


import org.springframework.data.jpa.repository.JpaRepository;


import com.library.mgmt.system.entity.Admin;



public interface AdminRepository extends JpaRepository<Admin,Integer>{
	//public Admin findByadminId(Long id);
}
