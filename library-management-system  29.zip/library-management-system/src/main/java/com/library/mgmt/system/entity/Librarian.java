package com.library.mgmt.system.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name="Librarian")
public class Librarian //extends Student
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int libId;
	private String libName;
	private String libEmail;
	private String libusername;
	private String libpassword;
	private String libMobno;
	private String libGender;
	private String libDOB;
	 

	 @OneToMany(mappedBy = "librarian", cascade = CascadeType.ALL)
	  private List<Book> books;

	  @OneToMany(mappedBy = "librarian", cascade = CascadeType.ALL)
	  private List<Student> students;

	  @OneToMany(mappedBy = "librarian", cascade = CascadeType.ALL)
	  private List<Faculty> faculties;
	
	 @OneToOne
	 @JoinColumn(name = "admin_id")
	 private Admin admin;

}
