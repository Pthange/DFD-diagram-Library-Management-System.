package com.library.mgmt.system.service;

import java.util.List;

import com.library.mgmt.system.dto.BookDTO;
import com.library.mgmt.system.entity.Book;

public interface BookService {

	BookDTO createBook(Book book);
	List<BookDTO> getAllBooks();
	BookDTO getBookById(int id);
	BookDTO getBookByTitle(String title);
	BookDTO updateBook(int id, Book book);
	String deleteBook(int id);

}
