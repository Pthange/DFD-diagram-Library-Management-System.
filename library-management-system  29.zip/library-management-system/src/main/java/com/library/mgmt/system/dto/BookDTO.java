package com.library.mgmt.system.dto;

import javax.persistence.CascadeType;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.library.mgmt.system.entity.Author;
import com.library.mgmt.system.entity.Faculty;
import com.library.mgmt.system.entity.Librarian;
import com.library.mgmt.system.entity.Student;

import lombok.Data;

@Data 
//Lombok's @Data annotation will automatically gives required methods like constructors,getter and setter
public class BookDTO //extends StudentDTO
{

	@NotNull(message="Book Title cannot be null")
	private String title;
	@NotNull(message="Author cannot be null")
	private String author;
	@NotBlank
	private String ISBN;
	@NotBlank(message="Enter Right Genre")
	private String genre;
	@NotBlank(message="Enter Right Book Language")
	private String language;
	
////	@ManyToOne(cascade = CascadeType.ALL)
////	@JsonManagedReference
//	//use JsonManagedReference for bidirectional relationship
//	private Student student;  
//	// Many-to-One relationship with the Student entity. CascadeType.ALL allows cascading operations.
//
////	@ManyToOne(cascade = CascadeType.ALL)
////	 @JsonBackReference
//	//use JsonManagedReference for bidirectional relationship
//	private Author authors;    
//	// Many-to-One relationship with the Author entity. CascadeType.ALL allows cascading operations.
//
////	@ManyToOne(cascade = CascadeType.ALL)
////	@JsonManagedReference
//	//use JsonManagedReference for bidirectional relationship
//	private Librarian librarian;  
//	// Many-to-One relationship with the Librarian entity. CascadeType.ALL allows cascading operations.
//
////	@ManyToOne(cascade = CascadeType.ALL)
////	@JsonManagedReference
//	//use JsonManagedReference for bidirectional relationship
//	private Faculty faculty;  
//	// Many-to-One relationship with the Faculty entity. CascadeType.ALL allows cascading operations.


}
