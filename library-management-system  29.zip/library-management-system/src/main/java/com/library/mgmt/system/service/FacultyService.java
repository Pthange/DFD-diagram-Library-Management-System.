package com.library.mgmt.system.service;

import java.util.List;

import com.library.mgmt.system.dto.FacultyDTO;
import com.library.mgmt.system.entity.Faculty;

public interface FacultyService 
{
	FacultyDTO createFaculty(Faculty faculty);
    List<FacultyDTO> getAllFaculties();
    FacultyDTO getFacultyById(int id);
    FacultyDTO updateFaculty(int id, Faculty faculty);
    String deleteFaculty(int id);

}
