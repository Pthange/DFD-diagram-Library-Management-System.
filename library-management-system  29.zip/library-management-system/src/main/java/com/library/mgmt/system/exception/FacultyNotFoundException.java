package com.library.mgmt.system.exception;
@SuppressWarnings("serial")
public class FacultyNotFoundException extends Exception{

	public FacultyNotFoundException(String message)
	{
		super(message);
	}

}
